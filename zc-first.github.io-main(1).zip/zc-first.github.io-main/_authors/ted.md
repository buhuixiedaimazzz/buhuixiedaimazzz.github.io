---
short_name: ted
name: Ted Doe
position: Writer
---
Ted has been eating fruit since he was baby.